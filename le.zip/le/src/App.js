import IndexRouter from "./router/IndexRouter";
import './App.css';
function App() {
  return <div className="app">
      <IndexRouter></IndexRouter>
  </div>
}

export default App;
